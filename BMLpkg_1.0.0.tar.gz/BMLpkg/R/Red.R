Red <-
function(matrix){
	changed.num.ratBack = swap(matrix);changed.num.ratBack
	Ready2Up = Turn2(changed.num.ratBack);Ready2Up
	Moved.right = oneUp.matrix(Ready2Up);Moved.right
	Origin.Dir = TurnBack2(Moved.right); Origin.Dir
	ready2plot = swap(Origin.Dir)
	return(ready2plot)
}
