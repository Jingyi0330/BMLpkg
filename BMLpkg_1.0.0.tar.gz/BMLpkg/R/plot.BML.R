plot.BML <-
function(x,...){
	image(x, col=c("white","red","blue"),axes=FALSE)
}
