Turn2 <-
function(mat){
	bat = turn.mat.90left(mat)
	cat = turn.mat.90left(bat)
	return(cat)
}
